package practice_project9;
interface First 
{  
    default void show() 
    { 
        System.out.println("First one is default"); 
    } 
} 
interface Second 
{  
    default void show() 
    { 
        System.out.println("Second one is default"); 
    } 
}  
public class Implements implements First,Second
{  
    public void show() 
    {  
        First.super.show(); 
        Second.super.show(); 
    } 
    public static void main(String args[]) 
    { 
        Implements ob = new Implements(); 
        ob.show(); 
    } 
}




